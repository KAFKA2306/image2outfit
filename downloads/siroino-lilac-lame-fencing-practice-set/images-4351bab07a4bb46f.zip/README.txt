Render images only; no usable VRChat outfit or fit/runtime approval.
siroino-lilac-lame-fencing-practice-set
